#' FlexRL: A Flexible Model for Record Linkage
#'
#' Links records that refer to the same entities across two data sources
#' without a unique identifier, using partially identifying variables.
#' These  are stable (not changing over time, probability of mistakes
#' could be bounded), flexible (dynamic but no information to model
#' changes over time) or structured (dynamic and information to model
#' changes over time, probability of mistakes could be fixed).
#' The main function [StEM()] fits a latent-variable model by stochastic
#' expectation-maximisation; it models registration errors (missing values
#' and mistakes) and changes over time. [prepare_data()] prepares the data
#' sources for record linkage, [RL_diagnostics()] gathers diagnostics
#' (FDP estimation and discrepancy metrics for  inference on the linked
#' data.
#'
#' Methodological paper: \doi{10.1093/jrsssc/qlaf016}.
#' False discovery proportion estimation: \doi{10.1002/sim.70292}.
#' Experiments repository: \url{https://github.com/robachowyk/FlexRL-experiments}.
#'
#' @author Kayané Robach
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib FlexRL, .registration=TRUE
#' @name FlexRL
#'
#' @examples
#' # Link two simulated sources with 4 PIVs: two stable, one flexible, one
#' # structured. The true links are known, so performance can be computed.
#' PIVs_config <- list( V1 = list(dynamics = "stable",
#'                                bound_mistakes = c(0.10,0.10),
#'                                fix_mistakes = c(NA,NA)),
#'                      V2 = list(dynamics = "stable",
#'                                bound_mistakes = c(0.10,0.10),
#'                                fix_mistakes = c(NA,NA)),
#'                      V3 = list(dynamics = "flexible",
#'                                bound_mistakes = c(NA,NA),
#'                                fix_mistakes = c(NA,NA)),
#'                      V4 = list(dynamics = "structured",
#'                                bound_mistakes = c(NA,NA),
#'                                fix_mistakes = c(0.03,0.03),
#'                                cond_hazard_cov = list(cov1=c("Xe", "Xf"),
#'                                                       cov2=c())) )
#' n_values  <- c( 5, 6, 7, 12 )
#' p_mistake <- list( V1 = c(0.02, 0.02), V2 = c(0.02, 0.02),
#'                   V3 = c(0.05, 0.05), V4 = c(0.02, 0.02) )
#' p_missing <- list( V1 = c(0.005, 0.005), V2 = c(0.005, 0.005),
#'                   V3 = c(0.005, 0.005), V4 = c(0.005, 0.005) )
#' cond_hazard_params <- list(V1 = c(), V2 = c(),
#'                            V3 = c(), V4 = log(c(0.7, 0.6, 0.5)))
#' gen_data <- simulate_data( PIVs_config, n_values, c(150, 200), 100,
#'                            p_mistake, p_missing, cond_hazard_params,
#'                            TRUE, survival_model("exponential") )
#' prep_data <- prepare_data( gen_data$data1, gen_data$data2, "1", "2",
#'                            PIVs_config, TRUE, "entity_id", TRUE )
#' fit <- StEM( data = prep_data, StEM_iter = 5, StEM_burnin = 2,
#'              gibbs_iter = 5, gibbs_burnin = 2, n_post_sample = 5 )
#'
#' # linked pairs and performance against the true pairs
#' linked <- fit$Delta[fit$Delta$x > 0.5, ]
#' linked_pairs <- paste(linked$i, linked$j, sep = "_")
#' true_pairs   <- paste(prep_data$true_pairs[[1]], prep_data$true_pairs[[2]], sep = "_")
#' tp <- length(intersect(linked_pairs, true_pairs))
#' fp <- length(setdiff(linked_pairs, true_pairs))
#' fn <- length(setdiff(true_pairs, linked_pairs))
#' c(LinkageDecisionRule = 0.5, FDP = fp / (tp + fp), Sensitivity = tp / (tp + fn))
#'
#' # diagnostics for inference on the linked data
#' diag <- RL_diagnostics(fit, prep_data$encodedA, prep_data$encodedB,
#'                        names(PIVs_config),
#'                        list(V1 = FALSE, V2 = FALSE, V3 = FALSE, V4 = TRUE),
#'                        names(PIVs_config),
#'                        true_pairs = prep_data$true_pairs, FDP_estimation = TRUE,
#'                        RL_method = "FlexRL", data = prep_data,
#'                        StEM_iter = 5, StEM_burnin = 2,
#'                        gibbs_iter = 5, gibbs_burnin = 2, n_post_sample = 5,
#'                        maxIter4CV = 1, n_repeats = 1)
#' diag # print(diag)
#' print(diag, threshold = 0.75)
#' plot(diag, "scores")
#' plot(diag, "distributions", threshold = 0.75)
#' plot(diag, "convergence")
#' plot(diag, "FDP")
#' plot(diag, "discrepancy")

"_PACKAGE"

NULL

.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "If you are happy with FlexRL, please cite us! If you are unhappy, please cite us anyway (and feel free to complain as well)."
  )
}
